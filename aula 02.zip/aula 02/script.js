//criando variaveis
let numeroUm = document.querySelector("#numeroUm");
let numeroDois = document.querySelector("#numeroDois");
let brSomar = document.querySelector("#brSomar");
let resultado = document.querySelector("#resultado");

//função de soma
function soma(){

    //variaveis que iram receber os input
    let num1 = Number(numeroUm.value);
    let num2 = Number(numeroDois.value);

    //somando usando as novas variaveis que estão recendo os input
    resultado.textContent = num1 + num2;

}

brSomar.onclick = function (){
    soma();
}

let Omelete = document.querySelector("#Omelete");
let ResultadoA = document.querySelector("#ResultadoA");
let ResultadoB = document.querySelector("#ResultadoB");
let BrResultado = document.querySelector("#BrResultado");

function calcular(){
    let num1 = Number(Omelete.value);

    ResultadoA.textContent = num1 * 2 + " Ovos";
    ResultadoB.textContent= num1 * 50 + " ,00  g Queijo"; 
}

BrResultado.onclick = function() {
    calcular()
}
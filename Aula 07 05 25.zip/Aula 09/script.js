let NumeroUm = document.querySelector("#NumeroUm");
let NumeroDois = document.querySelector("#NumeroDois");
let Soma = document.querySelector("#Soma");
let Subtracao = document.querySelector("#Subtracao");
let Divisao = document.querySelector("#Divisao");
let Multiplicacao = document.querySelector("#Multiplicacao");
let BrResultado = document.querySelector("#BrResultado");

function Somar(){
    let Num1 = Number(NumeroUm.value);
    let Num2 = Number(NumeroDois.value);

    Soma.textContent = (Num1 + Num2);
    Subtracao.textContent = (Num1 - Num2);
    Divisao.textContent = (Num1 / Num2);
    Multiplicacao.textContent = (Num1 * Num2);
}

BrResultado.onclick = function() {
    Somar()
}
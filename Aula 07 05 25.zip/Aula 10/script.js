let InputUm = document.querySelector("#InputUm");
let InputDois = document.querySelector("#InputDois");
let InputTres = document.querySelector("#InputTres");
let InputQuatro = document.querySelector("#InputQuatro");
let InputCinco = document.querySelector("#InputCinco");

let BrSomar = document.querySelector("#BrSomar");
let NumeroUm = document.querySelector("#NumeroUm");
let NumeroDois = document.querySelector("#NumeroDois");

function Somar(){
    let Pizza1 = (InputUm.value);
    let Pizza2 = (InputDois.value);
    let Pizza3 = (InputTres.value);
    let Pizza4 = (InputQuatro.value);
    let Refrigerante = (InputCinco.value);

    NumeroUm.textContent = Pizza1 + " " + Pizza2 + " " + Pizza3 + " " + Pizza4 + " " 

    NumeroDois.textContent = Refrigerante * 7 + 12 * 4 + " " + " R$"


}

BrSomar.onclick = function(){
    Somar()
}
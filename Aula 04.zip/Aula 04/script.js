let ValoKilo = document.querySelector("#ValorKilo");
let ValorFinal = document.querySelector("#ValorFinal");
let Resultado = document.querySelector("#resultado");
let SomarKilo = document.querySelector("#SomarKilo");

function somar(){
    let num1 = Number(ValoKilo.value);
    let num2 = Number(ValorFinal.value);

    resultado.textContent = num1 * num2;
}

SomarKilo.onclick = function (){
    somar();
}


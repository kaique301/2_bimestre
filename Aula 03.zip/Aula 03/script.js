    /*Faça uma página que receba um valor que é o valor pago, 
    um segundo valor que é o preço do produto e 
    retorne o troco a ser dado.
    */

    let ValorRecebido = document.querySelector("#ValorRecebido");
    let ValorTroco = document.querySelector("#ValorTroco");
    let resultado = document.querySelector("#resultado");
    let brSubtracao = document.querySelector("#brSubtracao");

    function somar (){

        let num1 = Number(ValorRecebido.value);
        let num2 = Number(ValorTroco.value);

        resultado.textContent = num1 - num2;
    }

    brSubtracao.onclick = function() {
        somar();
    }

